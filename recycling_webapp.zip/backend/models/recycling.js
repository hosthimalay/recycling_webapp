const mongoose = require('mongoose');

const recyclingSchema = new mongoose.Schema({
    user: String,
    type: String,
    amount: Number,
    earnings: Number,
    date: { type: Date, default: Date.now },
});

const Recycling = mongoose.model('Recycling', recyclingSchema);

module.exports = Recycling;